from Doctor import *
from Patient import *
import datetime

doctors = [
    Doctor("John", "Smith", "Cardiology"),
    Doctor("Emma", "Johnson", "Dermatology"),
    Doctor("Michael", "Brown", "Orthopedics"),
    Doctor("Sarah", "Williams", "Pediatrics"),
    Doctor("David", "Jones", "Neurology"),
]



discharged_patients = [    
    Patient("Johndsichage", "Smith", "30", "1234567890", "12345"),
    Patient("Janedsicha", "Doe", "25", "9876543210", "54321"),]

class Admin:
    def __init__(self, username, password, address =" "):
        self.__username = username
        self.__password = password
        self.__address =  address

    def get_username(self):
        return self.__username
    
    def get_password(self):
        return self.__password

    def view(self,a_list):
        for index, item in enumerate(a_list):
            print(f'{index+1:3}|{item}')

    def login(self) :
        
        print("-----Login-----")

        username = input('Enter the username: ')
        password = input('Enter the password: ')
        
        if username == self.__username and password == self.__password:
            print("You are loggedin")
            return True
        else:
            return False
        
    def view_admin_detail(self):
        print(f"The username is {self.__username}")
        print(f"The password is {self.__password}")
        print(f"The address is {self.__address}")
        
    def find_index(self,index,doctors):
                  
        if index in range(0,len(doctors)):
            
            return True
        else:
            return False
            
    def get_doctor_details(self) :
        first_name = input('Enter the first name: ')
        surname = input('Enter the surname: ')
        speciality = input('Enter the speciality: ')
        return first_name, surname, speciality 
        

    def doctor_management(self, doctors):
        while True:
            print("-----Doctor Management-----")

            print('Choose the operation:')
            print(' 1 - Register')
            print(' 2 - View')
            print(' 3 - Update')
            print(' 4 - Delete')
            print(' 5 - back')
            operation = input("Enter your operation: ")
            if operation =="1":
                print("-------Register-------")
                print("Enter the doctor's details: ")
                first_name = input("Enter the first name: ")
                surname = input("Enter the surname: ")
                speciality = input("Enter the speciality: ")

                for doctor in doctors:
                    if first_name == doctor.get_first_name() and surname == doctor.get_surname():
                        print('Name already exists.')
                        break

                else:   
                    doctor = Doctor(first_name, surname, speciality)
                    doctors.append(doctor)
                    print('Doctor registered.')

            elif operation == '2':
                print("\nList of doctors:")
                print(" ID|          FULL NAME           |   SPECIALITY   ")
                self.view(doctors)
            elif operation == '3':
                while True:
                    print("\n-----Update Doctor`s Details-----")
                    print("List of doctors:")
                    print('ID|          Full name           |     Speciality   ')
                    self.view(doctors)
                    index = int(input('Enter the ID of the doctor: ')) - 1
                    doctor_index=self.find_index(index,doctors)
                    if doctor_index == False:
                        print("Doctor not found")

                    else:
                        if doctor_index == True:
                            print('Choose the field to be updated:')
                            print(' 1. First name')
                            print(' 2. Surname')
                            print(' 3. Speciality')

                            field = input('Enter the field you want to update: ')
                            if field == '1':
                                new_first_name = input("Enter the new first name: ")
                                doctors[index].set_first_name(new_first_name)
                                print("first Name successfully changed! ")
                                break
                            elif field == '2':
                                new_surname = input("Enter the new last name: ")
                                doctors[int(index)].set_surname(new_surname)
                                print("Surame successfully changed! ")
                                break
                            elif field == '3':
                                new_speciality = input("Enter the new speciality: ")
                                doctors[int(index)].set_speciality(new_speciality)
                                print("Speciallity successfully changed! ")
                                break
                            else:
                                print("Invalid choice")
                                break
                        else:
                            print("The ID entered was not found")
                            break

            elif operation == '4': 
                print("-----Delete Doctor-----")
                print('ID |          Full Name           |  Speciality')
                self.view(doctors)

                index = int(input('Enter the ID of the doctor to be deleted: '))-1
                if self.find_index(index, doctors):
                    doctors.pop(int(index))
                    print("Doctor deleted")
                else:
                    print('The id entered is incorrect')
                    break
            elif operation == '5':
                break
            else:
                print('Invalid operation choosen. Check your spelling!')
                break
    
    def add_new_patient(self, patients):
        first_name = input("Enter the first name: ")
        surname = input("Enter the surname: ")
        age = input("Enter the age: ")
        mobile = input("Enter the mobile number: ")
        postcode = input("Enter the postcode: ")

        new_patient = Patient(first_name, surname, age, mobile, postcode)
        patients.append(new_patient)
        Patient.save_to_file('patient_data.txt', patients)
        print("New patient has been added.")
        
        

    def view_patient(self, patients):
        print("-----View Patients-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        # patients = Patient.load_from_file('patient_data.txt')
        self.view(patients)
        


    
    def add_symptoms_to_patient(self, patients):
        print("-----Add Symptoms to Patient-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        self.view(patients)

        patient_id = input("Enter the ID of the patient: ")

        try:
            patient_id = int(patient_id) - 1

            if patient_id not in range(len(patients)):
                print("Invalid patient ID.")
                return
            else:
                patient = patients[patient_id]
                symptoms = input("Enter symptoms: ")
                patient.print_symptoms(symptoms)
                print("Symptoms added successfully.")

        except ValueError:
            print("Invalid input. Please enter a valid patient ID.")

    def view_symptoms_of_patient(self, patients):
        print("-----View Symptoms of a Patient-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        self.view(patients)

        patient_id = input("Enter the ID of the patient: ")

        try:
            patient_id = int(patient_id) - 1

            if patient_id not in range(len(patients)):
                print("Invalid patient ID.")
                return
            else:
                patient = patients[patient_id]
                print(f"Symptoms of {patient.full_name()}: {patient.print_symptoms()}")

        except ValueError:
            print("Invalid input. Please enter a valid patient ID.")



    def relocate_patient(self, patients, doctors):
        print("-----Relocate-----")

        print("-----Patients-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        self.view(patients)

        patient_index = input('Please enter the patient ID: ')
        try:
            patient_index = int(patient_index)-1

            if patient_index not in range(len(patients)):
                print('The id entered was not found.')
                return 

        except ValueError: 
            print('The id entered is incorrect')
            return 

        print("-----Doctors Select-----")
        
        print('--------------------------------------------------')
        print('ID |          Full Name           |  Speciality   ')
        self.view(doctors)
        doctor_index = input('Please enter the doctor ID: ')


            
        try:
            doctor_index = int(doctor_index)-1

            if doctor_index not in range(len(doctors)):
                print('The ID entered was not found.')
                return

            patients[patient_index].link(doctors[doctor_index].full_name())
            self.view(patients)
            doctors[doctor_index].add_patient(patients[patient_index].full_name())
            print('The patient is now assigned to the new doctor.')
            
        except ValueError: 
            print('The id entered is incorrect')



    def assign_doctor_to_patient(self, patients, doctors):
        
        print("-----Assign-----")

        print("-----Patients-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        self.view(patients)

        patient_index = input('Please enter the patient ID: ')

        try:
            patient_index = int(patient_index)-1

            if patient_index not in range(len(patients)):
                print('The id entered was not found.')
                return 

        except ValueError: 
            print('The id entered is incorrect')
            return 

        print("-----Doctors Select-----")
        
        print('--------------------------------------------------')
        print('ID |          Full Name           |  Speciality   ')
        self.view(doctors)
        doctor_index = input('Please enter the doctor ID: ')

        try:
            doctor_index = int(doctor_index)-1

            if doctor_index not in range(len(doctors)):
                print('The ID entered was not found.')
                return

            appointment_date = datetime.datetime.now()   # Get current date
            patients[patient_index].link(doctors[doctor_index].full_name(), appointment_date)
            doctors[doctor_index].add_patient(patients[patient_index].full_name())
            doctors[doctor_index].add_appointment(appointment_date)
            print('The patient is now assigned to the doctor.')
            
        except ValueError: 
            print('The id entered is incorrect')

        
    def discharge(self, patients, discharged_patients):
        print("------View Patient-------")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        self.view(patients)
        choice = input("Do you want to discharge a patient (Y/N): ").lower()
        if choice == "y":
            print("-----Discharge Patient-----")
            try:
                patient_index = int(input("Please Enter the patient ID: "))-1
            except ValueError:
                print("Invalid input. Please enter a valid patient ID.")
            
            if self.find_index(patient_index, patients):
                discharge_patient = patients.pop(patient_index) 
                discharged_patients.append(discharge_patient)
                print(f"Patient {discharge_patient.full_name()} is discharged.")
            else:
                print("Invalid patient ID.")
        else:
            print("Not able to discharge.")
        


    def view_discharge(self, discharged_patients):
        print("-----Discharged Patients-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        self.view(discharged_patients)

    def admin_details(self):
        print(f"Username : {self.__username}")
        print(f"Password : {self.__password}")
        print(f"Address : {self.__address}")

    def update_details(self):
        print('Choose the field to be updated:')
        print(' 1. Username')
        print(' 2. Password')
        print(' 3. Address')
        op = input('Enter the field you want to update: ')

        try:
            if op == "1":
                self.admin_details()
                username1 = input('Enter the new username: ')
                username2 = input('Enter the new username again: ')
                if username1 == username2:
                    print("Username matched.")
                    self.__username = username2
                    print("------------------------------")
                    self.admin_details()
                    print("-----------Username updated--------------")
                else:
                    print("Username not matched")

            elif op == "2":
                self.admin_details()
                password = input('Enter the new password: ')
                if password == input('Enter the new password again: '):
                    self.__password = password
                    self.admin_details()
                    print("----------------Password updated---------------")

            elif op == "3":
                address = input('Enter the new address: ')
                if address == input('Enter the new address again: '):
                    self.__address = address
                    self.admin_details()
                    print("address updated.")

            else:
                print("Invalid choice. Please enter above mentioned one.")
        
        except ValueError as e:
            print(str(e))       

    def same_family(self):
        patients = Patient.load_from_file('patient_data.txt')
        same_family = {}
        for patient in patients:
            patient_surname = patient.get_surname()
            if patient_surname not in same_family:
                same_family[patient_surname] = [patient]
            else:
                same_family[patient_surname].append(patient)

        for surname, family_members in same_family.items():
            print(f"{surname} family:")
            for member in family_members:
                print(member)
            print()

    def report(self,patients):
        print("-----------------WELCOME TO REPORT CENTER-----------------------------")
        total_doctors = len(doctors)
        print(f"Total number of doctors: {total_doctors}")  

        total_patients = len(patients)
        print(f"The total number of patients is: {total_patients}")  

        for doctor in doctors:
            num_patients = sum(1 for patient in patients if patient.get_doctor() == doctor.full_name())
            print(f"The number of patients for {doctor.full_name()} is: {num_patients}")

        total_number_of_patients_based_on_illness = {}
        for patient in patients:
            patient_symptoms = patient.print_symptoms()
            for symptom in patient_symptoms:
                if symptom not in total_number_of_patients_based_on_illness:
                    total_number_of_patients_based_on_illness[symptom] = 1
                else:
                    total_number_of_patients_based_on_illness[symptom] += 1

        print("\nTotal number of patients based on the illness:")
        if not total_number_of_patients_based_on_illness:  
            print("None")
        else:
            for symptom, count in total_number_of_patients_based_on_illness.items():
                print(f"{symptom:<45}: {count:>3} patients")
        
        print("\nTotal number of appointments per month per doctor:")
        for doctor in doctors:
            appointments = doctor.get_appointments()
            print(f"{doctor.full_name()}:")
            if not appointments:
                print("   - None")
            else:
                for month, count in appointments.items():
                    print(f"   - {month}: {count} appointments")