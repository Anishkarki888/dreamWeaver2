class Patient:
    def __init__(self, first_name, surname, age, mobile, postcode):
        self.__first_name = first_name
        self.__surname = surname
        self.__age = age
        self.__mobile = mobile
        self.__postcode = postcode
        self.__symptom = [] 
        self.__doctor = 'None'
        self.appointment_date = 'None'
    
    def full_name(self) :
        return f"{self.__first_name} {self.__surname}"
    
    def get_surname(self):
        return self.__surname

    def get_doctor(self) :
        return self.__doctor

    def link(self, doctor, appointment_date):
        self.__doctor = doctor
        self.appointment_date = appointment_date

    def print_symptoms(self):
        return self.__symptom

    def set_symptoms(self, symptoms):
        self.__symptom.append(symptoms)

    @staticmethod
    def save_to_file(patient_data, patients):
        with open(patient_data, 'w') as file:
            for patient in patients:
                file.write(f"{patient.__first_name},{patient.__surname},{patient.__age},{patient.__mobile},{patient.__postcode}\n")

    @staticmethod
    def load_from_file(patient_data):
        patients = []
        try:
            with open(patient_data, 'r') as file:
                for line in file:
                    data = line.strip().split(',')
                    if len(data) == 5:  
                        patient = Patient(data[0], data[1], int(data[2]), data[3], data[4])
                        patients.append(patient)
            return patients
        except FileNotFoundError:
            print("File not found.")
            return []


    def __str__(self):
        return f'{self.full_name():^30}|{self.__doctor:^30}|{self.__age:^5}|{self.__mobile:^15}|{self.__postcode:^10}'
